const modifier = (text) => {
  
  if (state.stats["statPoints"] > 0 || state.skillPoints > 0) {
    state.displayStats = [{key:'You have unspent points! Open the menus to the right', value: '--->', color: 'red'}]
    state.displayStats.push({key:'\nXP', value: state.XP, color: 'green'})
  } else {
    state.displayStats = [{key:'XP', value: state.XP, color: 'green'}]
  }
  
  if (state.XP >= 100) {
    state.XP -= 100
    state.stats["statPoints"] += 1
    state.skillPoints += 10
    state.displayStats.push({key:'\nLevel up', value: 'Points added!', color: 'yellow'})
  }
  
  // BEGIN rpg mechanics
  intMod = state.stats["stats"]["Intelligence"]["level"]
  chaMod = state.stats["stats"]["Charisma"]["level"]
  wisMod = state.stats["stats"]["Wisdom"]["level"]
  strMod = state.stats["stats"]["Strength"]["level"]
  dexMod = state.stats["stats"]["Dexterity"]["level"]
  conMod = state.stats["stats"]["Constitution"]["level"]
  
  console.log(info?.inputEvaluation)
  
  chkAtt = info?.inputEvaluation["attribute"]
  chkDC = info?.inputEvaluation["DC"]
  chkCuz = info?.inputEvaluation["reason"]
  
  if (history.length >= 2) {
    if (state.showDC) {
      state.message = chkAtt + " DC " + chkDC + ": " + chkCuz
    } else {
      state.message = chkCuz
    }
  }
  
  chkXP = chkDC/5
  
  if (chkAtt != null) {
    if (chkAtt.includes("Any")) {
      chkCurAtt = 0
      chkAttPosAdj = "good"
      chkAttNegAdj = "bad"
    }
    if (chkAtt.includes("Intelligence")) {
      chkCurAtt = intMod
      chkAttPosAdj = "smart"
      chkAttNegAdj = "dumb"
    }
    if (chkAtt.includes("Wisdom")) {
      chkCurAtt = wisMod
      chkAttPosAdj = "wise"
      chkAttNegAdj = "oblivious"
    }
    if (chkAtt.includes("Charisma")) {
      chkCurAtt = chaMod
      chkAttPosAdj = "charming"
      chkAttNegAdj = "annoying"
    }
    if (chkAtt.includes("Strength")) {
      chkCurAtt = strMod
      chkAttPosAdj = "strong"
      chkAttNegAdj = "weak"
    }
    if (chkAtt.includes("Dexterity")) {
      chkCurAtt = dexMod
      chkAttPosAdj = "nimble"
      chkAttNegAdj = "clumsy"
    }
    if (chkAtt.includes("Constitution")) {
      chkCurAtt = conMod
      chkAttPosAdj = "tough"
      chkAttNegAdj = "scrawny"
    }
    
    if (typeof(state.chkSitBonus) !== 'undefined') {
      chkCurSit = chkCurAtt + state.chkSitBonus
    } else {
      chkCurSit = chkCurAtt
    }
    
    roll = getRndInteger(1,20)
    chkModRoll = roll + chkCurSit
    if (chkModRoll >= chkDC) {
      chkResult = "Success!"
      resultContextString = "[You are " + chkAttPosAdj + " enough for that right now.]"
      state.XP += chkXP
    } else {
      chkResult = "Fail!"
      resultContextString = "[You are too " + chkAttNegAdj + " for that right now.]"
      if (chkXP > 1) {
        chkXP = Math.floor(chkXP/2)
      }
      state.XP += chkXP
    }
    
    if (history.length >= 2) {
      state.message += " " + chkAtt + " roll: " + chkModRoll + "(" + roll + makeModString(chkCurAtt) + makeModString(state.chkSitBonus) + "), " + chkResult + " XP gained: " + chkXP
    }
    
    if (typeof(state.chkSitBonus) !== 'undefined') {
      delete state.chkSitBonus
    }
  }
  // END rpg mechanics
  
  const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength + 1) : text
  const lines = context.split("\n")
  
  // BEGIN rpg mechanics
  if (typeof(resultContextString) !== 'undefined') {
      lines.splice(-1, 0, resultContextString)
  }
  // END rpg mechanics
  
  const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  var finalText = [contextMemory, combinedLines].join("")
  return { text: finalText }
}

// Don't modify this part
modifier(text)
