const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()
  
  // START of placeholder grab thing
  // Grab the placeholders on first input, show them in message, clean brackets from input
  // if you have an init function that runs only once, put this under it
  if (history.length <= 1) { // Only on first input
    grabAllBrackets() // get bracket contents into state.placeholders
    state.message = "Grabbed brackets:" + state.placeholders.join(", ") // nicely show what was grabbed
    modifiedText = text.replace(/\[|\]/g, '') // clean up the text taht goes into history
  }
  // END of placeholder grab thing
  
  return { text: modifiedText }
}
// Don't modify this part
modifier(text)
