// FixQuotes:
// RegEx matchers:
const quoted = /"(.*?)"/g
const openQuote = /"(.*?)\%\%\%/g // %%% arbritrarily chosen as end marker
// Utility functions:
function grabQuoted(index = 0) {
  return (text.match(quoted)[index])}
function grabAllQuoted(chkString = text) {
  return (JSON.stringify(chkString.match(quoted)))}
function grabOpenQuote(chkString = text) {
  return (chkString.match(openQuote))}
// Main function:
function fixQuotes(verbose = false) {
  if (verbose) {state.message = ""}
  var lines = text.split('\n')
  var newLines = []
  for (line of lines) {
    if (line.includes('\"')) {
      let checkLine = line.replace(quoted, "") + "%%%"// Remove legit quotes from check; add end marker for open quote matching
      if (checkLine.match(openQuote)) {
        if (verbose) {state.message += line + " -> "}
        checkLine = checkLine.match(openQuote)[checkLine.match(openQuote).length - 1]
        checkLine = checkLine.replace('%%%', "")
        checkLine = checkLine.replace('\"', "")
        if (checkLine) {// null ~= false, so only trigger if the open quote contains anything
          if (verbose) {state.message += "Added missing end quote: " + line + "\"\n"}
          newLines.push(line + '\"')
        } else {// Leave properly trailing quotes
          if (verbose) {state.message += "Trailing quote found, pushing in good faith.\n"}
          newLines.push(line)
        }
      } else {
        if (verbose) {state.message += "No open quote found, pushing.\n"}
        newLines.push(line)
      }
    } else {
      if (verbose) {state.message += "No quote found, pushing.\n"}
      newLines.push(line)
    }
  }
  return(newLines.join("\n"))
}
// FixQuotes END
