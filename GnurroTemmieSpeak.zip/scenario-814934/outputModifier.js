const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()

  return {text: modifiedText}
}

// Don't modify this part
modifier(text)
