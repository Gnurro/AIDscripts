// misc helper functions
function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min) ) + min;
}

// list of words to replace with random words
const badNames = ["Grey","Kyros","Rostov","Ebon","Meliodas","Svelk","Dendrin"]

// vowels, no particular order
const vowels = ["a","e","u","i","o","y"];

// consonants, (not yet ordered by sonority)
const consonants = ["qu","w","s","d","f","ch","d","c","r","t","z","g","v","b","h","n","j","k","m","l","p"];


function getRndSnd(sndType) {
  if (sndType == "vowel") {
    return (vowels[getRndInteger(0, vowels.length)])
  } else if (sndType == "consonant") {
    return (consonants[getRndInteger(0, consonants.length)])
  }
}

function makeSyllable() {
  syl = getRndSnd("consonant")
  syl += getRndSnd("vowel")
  syl += getRndSnd("consonant")
  return (syl)
}

function makeWord(numSyls) {
  newWord = makeSyllable()
  for (let curSyls = 0; curSyls < numSyls-1; curSyls++) {
    newWord += makeSyllable();
  }
  return (newWord)
}