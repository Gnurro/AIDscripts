

const modifier = (text) => {
  let modifiedText = text
  
  for (word of badNames) {
    newWord = makeWord(3)
    matcher = new RegExp(word, 'gi')
    text = text.replace(matcher, newWord.replace(/^./, newWord[0].toUpperCase()))
  }
  
  modifiedText = text
  
  return { text: modifiedText }
}

// Don't modify this part
modifier(text)
