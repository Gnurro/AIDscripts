// Form shift and maintanence
// by Gnurro
// Original by Kitty

// Add/change forms on this list to change into with a simple /'form' input:
const shortFormsBase = ["werewolf", "human"]