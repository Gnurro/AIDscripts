const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()
  
  // BEGIN Encounters
  
  // Debugging action counter: (uncomment to better check global timer-only encounters)
  // state.displayStats = [{key:'Actions', value: `${info.actionCount}`}]
  
  // encounter trigger processing
  if (!state.currentEncounter) {
    globalLoop:
    for (encounter in encounterDB) { // go through encounters
      console.log(`Global checking '${encounter}'...`)
      if (encounterDB[encounter].inputLock) {
      console.log("Input checking disabled on this encounter.")
      continue globalLoop
      }
      /* for outputMod:
      if (encounterDB[encounter].outputLock) {
        console.log("Output checking disabled on this encounter.")
        continue globalLoop
      }
      */
      // limiting encounter recurrence:
      if (state.limitedEncounters) {
        limitLoop:
        for (limiter of state.limitedEncounters) {
          if (limiter[0] == encounter) {
            console.log(`${encounter} recurrence has a limit.`)
            if (limiter[1] > 0) {
              console.log(`${limiter[0]} can still happen ${limiter[1]} times.`)
              break limitLoop
            } else {
              console.log(`${limiter[0]} can't happen anymore.`)
              continue globalLoop
            }
          }
        }
      }
      if (state.cooldownEncounters) {
        cooldownLoop:
        for (cooldown of state.cooldownEncounters) {
          if (cooldown[0] == encounter) {
            console.log(`${encounter} has an active cooldown.`)
            continue globalLoop
          }
        }
      }
      if (typeof(encounterDB[encounter].globalActionDelay) == 'undefined') {
        console.log(`No global delay on '${encounterDB[encounter].encounterID}'!`)
        globalActionDelay = 0
      } else {
        globalActionDelay = encounterDB[encounter].globalActionDelay
      }
      if (info.actionCount < globalActionDelay) {
        continue globalLoop
      }
      console.log(`Hit more then ${globalActionDelay} total actions, allowing '${encounter}'!`)
      if (encounterDB[encounter].triggers) {
        triggerLoop:
        for (triggerStr of encounterDB[encounter].triggers) {
          console.log(triggerStr)
          triggerRegEx = new RegExp(triggerStr, "gi")
          caughtTrigger = text.match(triggerRegEx)
          if (caughtTrigger) {
            console.log(`Caught ${caughtTrigger}, setting '${encounter}'!`)
            if (!encounterDB[encounter].chance) {
              console.log(`No chance on triggered '${encounterDB[encounter].encounterID}' detected, this is probably an error!`)
            } else {
              console.log(`${encounterDB[encounter].chance}% chance detected!`)
              if (getRndInteger(1, 100) <= encounterDB[encounter].chance) {
                console.log(`Rolled below ${encounterDB[encounter].chance} chance, running '${encounter}'!`)
                updateCurrentEncounter(encounter)
                break globalLoop
              }
            }
          }/* else {
            console.log(`None of the triggers of '${encounterDB[encounter].encounterID}' detected in (text), moving on.`)
            //continue globalLoop
          }*/
        }
      } else {
        console.log(`No triggers for '${encounter}' found, check chance...`)
        if (encounterDB[encounter].chance) {
          console.log(`${encounterDB[encounter].chance}% chance detected!`)
          if (getRndInteger(1, 100) <= encounterDB[encounter].chance) {
            console.log(`Rolled below ${encounterDB[encounter].chance} chance, running '${encounter}'!`)
            updateCurrentEncounter(encounter)
            break globalLoop
          }
        } else {
          console.log(`No chance on '${encounterDB[encounter].encounterID}' detected, so it's probably a chain-only encounter!`)
          continue globalLoop
        }
      }
    }
  }
        
  // encounter timers:
  if (state.currentEncounter) {
    if (state.currentEncounter.triggerDelay) {
      console.log(`Delaying by ${state.currentEncounter.triggerDelay} actions before running '${state.currentEncounter.encounterID}'!`)
      state.currentEncounter.triggerDelay -= 1
    } else {
      console.log(`Done delaying, running '${state.currentEncounter.encounterID}'!`)
      // activating encounters:
      updateCurrentEffects()
      if (state.currentEncounter.memoryAdd) {
        if (!state.encounterMemories) {
          state.encounterMemories = []
        }
        state.encounterMemories.push(state.currentEncounter.memoryAdd)
      }
      if (!state.currentEncounter.textInserted) {
        if (state.currentEncounter.textNotes) {
          modifiedText += ` ${getRndFromList(state.currentEncounter.textNotes)}`
          state.currentEncounter.textInserted = true
        } else if (state.currentEncounter.textNotesWeighted) {
          modifiedText += ` ${getRndFromListWeighted(state.currentEncounter.textNotesWeighted)}`
          state.currentEncounter.textInserted = true
        }
      }
      if (state.currentEncounter.addWI) {
        for (WIentry in state.currentEncounter.addWI) {
          console.log(`Adding '${state.currentEncounter.addWI[WIentry].keys}' WI entry.`)
          addWorldEntry(state.currentEncounter.addWI[WIentry].keys, state.currentEncounter.addWI[WIentry].entry, state.currentEncounter.addWI[WIentry].hidden)
        }
      }
      // ending encounters:
      if (state.currentEncounter.endTriggers) {
        console.log(`${state.currentEncounter.encounterID} has end triggers!`)
        for (triggerStr of state.currentEncounter.endTriggers) {
          triggerRegEx = new RegExp(triggerStr, "gi")
          caughtTrigger = text.match(triggerRegEx)
          if (caughtTrigger) {
            console.log(`Caught ${caughtTrigger}, ending '${state.currentEncounter.encounterID}'!`)
            // limiting encounter recurrence:
            if (state.currentEncounter.recurrenceLimit) {
              if(!state.limitedEncounters) {
                state.limitedEncounters = []
                state.limitedEncounters.push([state.currentEncounter.encounterID, state.currentEncounter.recurrenceLimit-1])
              } else {
                for (limiter of state.limitedEncounters) {
                  if (limiter[0] == state.currentEncounter.encounterID) {
                    console.log(`'${state.currentEncounter.encounterID}' recurrence already has a limit.`)
                    if (limiter[1] > 0) {
                      limiter[1] = limiter[1]-1  
                    }
                  } else {
                    state.limitedEncounters.push([state.currentEncounter.encounterID, state.currentEncounter.recurrenceLimit-1])
                  }
                }
              }
            }
            
            if (state.currentEncounter.cooldown) {
              if(!state.cooldownEncounters) {
                state.cooldownEncounters = []
              }
              state.cooldownEncounters.push([state.currentEncounter.encounterID, state.currentEncounter.cooldown])
            }
            
            if (state.currentEncounter.chained || state.currentEncounter.chainedWeighted) {
              console.log(`Detected chained encounter(s) on ${state.currentEncounter.encounterID}!`)
              delete state.message
              delete state.encounterNote
              if (state.currentEncounter.chained) {
                console.log(`Chained encounter(s) on ${state.currentEncounter.encounterID} are not weighted.`)
                updateCurrentEncounter(getRndFromList(state.currentEncounter.chained))
              } else if (state.currentEncounter.chainedWeighted) {
                console.log(`Chained encounters on ${state.currentEncounter.encounterID} are weighted.`)
                updateCurrentEncounter(getRndFromListWeighted(state.currentEncounter.chainedWeighted))
              }
            } else {
              updateCurrentEncounter()
              updateCurrentEffects()
            }
          }
        }
      }
      
      if (typeof(state.currentEncounter.duration) !== 'undefined') {
        if (state.currentEncounter.duration > 0) {
          console.log(`Keeping up ${state.currentEncounter.encounterID} for ${state.currentEncounter.duration} more actions!`)
          state.currentEncounter.duration -= 1
        } else {
          console.log(`Duration of ${state.currentEncounter.encounterID} over!`)
          // limiting encounter recurrence:
          if (state.currentEncounter.recurrenceLimit) {
            if(!state.limitedEncounters) {
              state.limitedEncounters = []
              state.limitedEncounters.push([state.currentEncounter.encounterID, state.currentEncounter.recurrenceLimit-1])
            } else {
              for (limiter of state.limitedEncounters) {
              if (limiter[0] == state.currentEncounter.encounterID) {
                console.log(`${state.currentEncounter.encounterID} recurrence already has a limit.`)
                if (limiter[1] > 0) {
                  limiter[1] = limiter[1]-1  
                }
              } else {
                state.limitedEncounters.push([state.currentEncounter.encounterID, state.currentEncounter.recurrenceLimit-1])
              }
            }
          }
        }
        if (state.currentEncounter.cooldown) {
          if(!state.cooldownEncounters) {
            state.cooldownEncounters = []
          }
          state.cooldownEncounters.push([state.currentEncounter.encounterID, state.currentEncounter.cooldown])
        }
        if (state.currentEncounter.chained || state.currentEncounter.chainedWeighted) {
            console.log(`Detected chained encounter(s) on ${state.currentEncounter.encounterID}!`)
            delete state.message
            delete state.encounterNote
            if (state.currentEncounter.chained) {
              console.log(`Chained encounter(s) on ${state.currentEncounter.encounterID} not weighted.`)
              updateCurrentEncounter(getRndFromList(state.currentEncounter.chained))
            } else if (state.currentEncounter.chainedWeighted) {
              console.log(`Chained encounters on ${state.currentEncounter.encounterID} are weighted.`)
              updateCurrentEncounter(getRndFromListWeighted(state.currentEncounter.chainedWeighted))
            }
          } else {
            updateCurrentEncounter()
            updateCurrentEffects()
          }
        }
      } else {
        console.log(`No duration on ${state.currentEncounter.encounterID}, keeping it up infinitely!`)
      }
    }
  }
  
  // encounter memory stuff:
  if (state.encounterMemories) {
    for (encounterMemory of state.encounterMemories) {
      if (encounterMemory.memoryLingerDuration > 0) {
        encounterMemory.memoryLingerDuration -= 1
        console.log(`'${encounterMemory.memoryText}' will stay in memory for ${encounterMemory.memoryLingerDuration} more actions.`)  
      } else {
        delete state.encounterMemories.encounterMemory
      }
    }
  }
  
  if (state.cooldownEncounters) {
    console.log(`Cooldowns detected!`)
    for (cooldown in state.cooldownEncounters) {
      console.log(`'${state.cooldownEncounters[cooldown][0]}' (${cooldown}) cooldown: ${state.cooldownEncounters[cooldown][1]}.`)
      state.cooldownEncounters[cooldown][1] -= 1
      if (state.cooldownEncounters[cooldown][1] < 1) {
        console.log(`${state.cooldownEncounters[cooldown][0]} cooldown over, removing.`)
        delete state.cooldownEncounters[cooldown]
      }
      if (state.cooldownEncounters[0] == null) {
        console.log(`No more cooldowns, removing array.`)
        delete state.cooldownEncounters
      }
    }
  }
  // END Encounters
  
  return { text: modifiedText }
}

// Don't modify this part
modifier(text)
