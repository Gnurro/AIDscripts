const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()
  
  // BEGIN custom script
  // utility stuff:
  stopInput = false // good to have
  
  if (lowered.includes("/r")) { // /r command - this will reset ALL stats and skills!
    delete state.init // init block will run again
    state.message = "Init reset done."
    stopInput = true // no model call
  }
  
  // START of placeholder grab thing
  // Grab the placeholders on first input, show them in message, clean brackets from input
  // if you have an init function that runs only once, put this under it
  if (history.length <= 1) { // Only on first input
    grabAllBrackets() // get bracket contents into state.placeholders
    //state.message = "Grabbed brackets:" + state.placeholders.join(", ") // nicely show what was grabbed
    console.log("Grabbed brackets:" + state.placeholders.join(", "))
    modifiedText = text.replace(/\[|\]/g, '') // clean up the text taht goes into history
  }
  // END of placeholder grab thing
  
  // BEGIN RPG mechanics
  // still utility:
  if(!state.showDC) {
    state.showDC = false
  }
  
  if (lowered.includes("/showdc")) { // /showDC command
    if(state.showDC == true) {
      state.showDC = false
      state.message = "Turned DC display off."
    }
    if(state.showDC == false) {
      state.showDC = true
      state.message = "Turned DC display on."
    }
    stopInput = true // no model call
  }
  
  if (lowered.includes("/derpmode")) { // /derpmode command - enables stupid things
    if(state.disableRandomSkill == true) {
      state.disableRandomSkill = false
      state.message = "Turned random skills on."
    }
    if(state.disableRandomSkill == false) {
      state.disableRandomSkill = true
      state.message = "Turned random skills off."
    }
    stopInput = true // no model call
  }
  
  // "character classes":
  //witch = {'Potion Brewing':0, 'Dancing':0, 'Alligator Handling':0, 'Cackling':0}
  witch = {'Potion Brewing':0, 'Dancing':0, 'Cackling':0}
  petString = state.placeholders[2]
  petString = petString.charAt(0).toUpperCase() + petString.slice(1) + ' Handling'
  witch[petString] = 0
  barbarian = {'Rock Throwing':0, 'Rageing':0, 'Heavy Lifting':0, 'Intimidating':0}
  kobold = {'Trap Building':0, 'Hiding':0, 'Dragon Imitating':0, 'Mining':0}
  
  if (history.length <= 1) { // Only on first input
    classString = state.placeholders[1].toLowerCase()
    state.charClass = kobold // default to kobold :D
    if (classString == "witch") {
      state.charClass = witch
    }
    if (classString == "barbarian") {
      state.charClass = barbarian
    }
    if (classString == "kobold") {
      state.charClass = kobold
    }
  }
  
  // init
  if (!state.init) {
      // initialize stats fitting with InputDCattributeBot; these are straight-up attribute modifiers, unlike usual D20 systems
      state.stats = {stats:{Strength:{level: 0, cost:1}, Dexterity:{level: 0, cost:1}, Constitution:{level: 0, cost:1}, Intelligence:{level: 0, cost:1}, Wisdom:{level: 0, cost:1}, Charisma:{level: 0, cost:1},}, statPoints:5}
      // initialize skills; more on skill format and values below
      state.skills = state.charClass
      state.skillPoints = 10
      state.disableRandomSkill = true
      state.XP = 0
      state.init = true
  }
  
  // iterate over stats, raise costs if 4 or over
  for (att in state.stats["stats"]) {
    if (state.stats["stats"][att]["level"] >= 4) {
      console.log(att + " over 3, setting cost to 2")
      state.stats["stats"][att]["cost"] = 2
    }
    // infoString = att + " " + state.stats["stats"][att]["level"]
    // console.log(infoString)
  }
  
  // make a object containing skill boosts; will be triggered based on input below
  skillBoosts = {}
  for (skill in state.skills) { // go through skills
    skillLow = skill.toLowerCase() // for compatibility, and cuz vanilla does it this way (I generally don't like this, for reasons.)
    skillRoot = skillLow.split(" ") // assumes concise skill format with '(noun) verb-ing' for all skills
    if (skillRoot.length >= 2) { // if it's a noun skill
      skillVerb = skillRoot[1] // grab both the verb...
      skillNoun = skillRoot[0] // ...and the noun
    } else { // if it's only one word...
      skillVerb = skillLow // ...assume it's a verb-only skill
      if (typeof(skillNoun) !== 'undefined') { // sanity
        delete skillNoun // sanity
      }
    }
    skillVerb = skillVerb.split("ing")[0] // strip off 'ing' to get verb root
    //console.log(skillVerb)
    
    skillMod = state.skills[skill] // get skill modifier
    
    if (typeof(skillNoun) !== 'undefined') { // if there's a skillNoun, this is a noun+verb skill, so...
      //console.log(skillNoun)
      skillBoosts[skillNoun] = skillMod // ...add the noun to the boosts, with the appropriate bonus
      if (skillMod >= 10) { // if skill is 10 or higher...
        loweredSkillMod = skillMod - 9 // ...make lower bonus...
        skillBoosts[skillVerb] = loweredSkillMod // ...and add the verb to the boosts as well
      }
    } else { // if there's no noun...
      skillBoosts[skillVerb] = skillMod // ...simply add the verb to boosts, with the appropriate bonus
    }
    //console.log(skillMod)
  }
  console.log(skillBoosts)
  
  // set up situational skill bonus:
  for (boost in skillBoosts) { // go through all boosts
    if (lowered.includes(boost)) { // check if input has skill word
      console.log("caught " + boost + " skill, adding boost")
      if (!state.chkSitBonus) { // make stat.var to grab in contextMod
        state.chkSitBonus = 0
      }
      if (skillBoosts[boost] > state.chkSitBonus) { // if higher boost...
        state.chkSitBonus = skillBoosts[boost] // ...use it
      }
    }
  }
  
  if (!stopInput) {
    state.inputBot = 'InputDCattributeBot'
  }
  // END RPG mechanics
   
  return { text: modifiedText, stop:stopInput }
}

// Don't modify this part
modifier(text)
