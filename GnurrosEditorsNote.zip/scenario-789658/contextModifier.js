const modifier = (text) => {
  const memory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
  const context = info.memoryLength ? text.slice(info.memoryLength + 1) : text
  const lines = context.split("\n")
  var combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
  var finalText = [memory, combinedLines].join("")
  
  
  // Editor's Note:
  finalText = finalText.replace("Author\'s note:", "Editor\'s note:")
  
  
  return { text: finalText }
}

// Don't modify this part
modifier(text)
