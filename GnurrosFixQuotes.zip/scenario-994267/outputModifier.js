const modifier = (text) => {
  let modifiedText = text// This boilerplate is needed for FixQuotes!
  
  // FixQuotes:
  // Fix quotes in AI outputs:
  modifiedText = fixQuotes(verbose = true)
  // FixQuotes END
  
  return { text: modifiedText }
}

// Don't modify this part
modifier(text)
