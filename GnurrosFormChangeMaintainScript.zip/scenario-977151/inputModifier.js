// Form shift and maintenance
// Commands:
// /'shortForm': Quick access to form in shortForm list (in sharedLibrary).
// /changeto X: Changes your form to X.
// /checkform: Display current form.
// /trackform: Toggle constant display of current form maintained.
// /addform X: Adds X to the shortForm list. (Creates adventure state holding list of short form commands.)

const modifier = (text) => {
  let stop = false
  const commandMatcher = text.match(/\n? ?(?:> You |> You say "|)\/(\w+?)( [\w ]+)?[".]?\n?$/i)
  if (commandMatcher) {
    const command = commandMatcher[1]
    const args = commandMatcher[2] ? commandMatcher[2].trim().split(' ') : []
    
    if (state.shortForms) {
      var shortForms = state.shortForms
    } else {
      var shortForms = shortFormsBase
    }
    
    for (form of shortForms) {
      if (command == form) {
        state.form = form
      }
    }
    
    if (command == "changeto") {
      state.form = args[0];
    }
    
    if (command == "trackform") {
      if (!state.trackForm) {
        state.trackForm = true
        state.message = "You maintain your " + state.form + " form."
      } else if (state.trackForm) {
        state.trackForm = false
        delete state.trackForm
        state.message = ""
      }
    } else if (command == "checkform") {
      state.message = "You are in your" + state.form + " form."
    } else {
      state.message = "You take on your " + state.form + " form."
    }
    
    if (command == "addform") {
      if (!state.shortForms) {
        state.shortForms = []
        state.shortForms.concat(shortFormsBase)
      }
      state.shortForms.push(args[0])
      state.message = "Added /" + args[0] + " to the short form commands."
    }
    
    stop = true
    text = null
  }
  return { text, stop }
}

// Don't modify this part
modifier(text)