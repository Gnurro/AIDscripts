const modifier = (text) => {
  let modifiedText = text// This boilerplate is needed for FixQuotes!
  
  // FixQuotes:
  // Fix quotes in player inputs: (Useful if using 'story' or 'do' to say something.)
  modifiedText = fixQuotes(verbose = true)
  // FixQuotes END
  
  return { text: modifiedText }
}

// Don't modify this part
modifier(text)
