function rngCaps(playerInput) {
  let result = '';
  for (let letter of playerInput) {
    if (Math.random() >= 0.5) {
      letter = letter.toUpperCase()
    }
    result += letter;
  }
  return result
}

function rngDrop(playerInput) {
  let result = '';
  for (let letter of playerInput) {
    if (Math.random() >= 0.1) {
      result += letter;
    }
  }
  return result
}

const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()
    
  if(lowered.includes('/gocollege')) {    
    state.college = true
    modifiedText = text + '\nYou went to college!'
  }
  
  if(history.length>=1){
  
    if(!state.college==true){
     modifiedText = rngCaps(modifiedText)
     modifiedText = rngDrop(modifiedText)
    }
  
    if(!(modifiedText.includes('>')) && text.includes('>')){
      modifiedText = '>' + modifiedText
    }
    
    if(!(modifiedText.includes('\n'))){
      modifiedText = '\n' + modifiedText
    }
    
    if(!(modifiedText.includes('.'))){
      modifiedText = modifiedText + '.'
    }
  }
  
  return {text: modifiedText}
}

// Don't modify this part
modifier(text)
