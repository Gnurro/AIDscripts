const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()
  
  // BEGIN custom script
  // utility stuff:
  stopInput = false // good to have
  
  if (lowered.includes("/r")) { // /r command - this will reset ALL stats and skills!
    delete state.init // init block will run again
    state.message = "Init reset done."
    stopInput = true // no model call
  }
  
  // START of placeholder grab thing
  // Grab the placeholders on first input, clean brackets from input
  // if you have an init function that runs only once, put this under it
  if (history.length <= 1) { // Only on first input
    grabAllBrackets() // get bracket contents into state.placeholders
    console.log("Grabbed brackets:" + state.placeholders.join(", "))
    modifiedText = text.replace(/\[|\]/g, '') // clean up the text taht goes into history
  }
  // END of placeholder grab thing
  
  // BEGIN RPG mechanics
  // still utility:
  if(!state.showDC) {
    state.showDC = false
  }
  
  if (lowered.includes("/showdc")) { // /showDC command
    if(state.showDC == true) {
      state.showDC = false
      state.message = "Turned DC display off."
    }
    if(state.showDC == false) {
      state.showDC = true
      state.message = "Turned DC display on."
    }
    stopInput = true // no model call
  }
  
  if (lowered.includes("/derpmode")) { // /derpmode command - enables stupid things
    if(state.disableRandomSkill == true) {
      state.disableRandomSkill = false
      state.message = "Turned random skills on."
    }
    if(state.disableRandomSkill == false) {
      state.disableRandomSkill = true
      state.message = "Turned random skills off."
    }
    stopInput = true // no model call
  }
  
  // "character classes"/skillsets:
  // These must follow this format to work as intended!
  // witch:
  witch = {'Potion Brewing':0, 'Dancing':0, 'Cackling':0}
  petString = state.placeholders[2] // get the pet type the player typed in...
  petString = petString.charAt(0).toUpperCase() + petString.slice(1) + ' Handling' // ...put it in a fitting skill string...
  witch[petString] = 0 // ...and add the pet skill to the skills with zero skill ranks
  // barbarian:
  barbarian = {'Rock Throwing':0, 'Rageing':0, 'Heavy Lifting':0, 'Intimidating':0}
  // kobold:
  kobold = {'Trap Building':0, 'Hiding':0, 'Dragon Imitating':0, 'Mining':0}
  
  if (history.length <= 1) { // Only on first input
    classString = state.placeholders[1].toLowerCase() // make sure that any capitalization works
    state.charClass = kobold // default to kobold :D
    // assign typed-in class, if it's defined: --FIX: do this smarter/dynamically
    if (classString == "witch") {
      state.charClass = witch
    }
    if (classString == "barbarian") {
      state.charClass = barbarian
    }
    if (classString == "kobold") {
      state.charClass = kobold
    }
  }
  
  // initialize all the things!
  if (!state.init) { // but only if they aren't, yet
      // initialize stats fitting with InputDCattributeBot:
      state.stats = {stats:{Strength:{level: 0, cost:1}, Dexterity:{level: 0, cost:1}, Constitution:{level: 0, cost:1}, Intelligence:{level: 0, cost:1}, Wisdom:{level: 0, cost:1}, Charisma:{level: 0, cost:1},}, statPoints:5}
      // initialize skills; more on skill format and values below:
      state.skills = state.charClass // state.skills enables the skills menu; class skills object must fit with it!; definitions above
      state.skillPoints = 10
      state.disableRandomSkill = true
      state.XP = 0
      state.init = true // so it knows it's been initialized
  }
  
  // iterate over stats, raise costs if 4 or over:
  for (att in state.stats["stats"]) {
    if (state.stats["stats"][att]["level"] >= 4) {
      console.log(att + " over 3, setting cost to 2")
      state.stats["stats"][att]["cost"] = 2
    }
  }
  
  // make an object containing skill boosts; input will be checked for these below:
  skillBoosts = {} // make empty object/clear prior boosts
  
  for (skill in state.skills) { // go through skills
    skillLow = skill.toLowerCase() // for compatibility, and cuz vanilla does it this way (I generally don't like this, for reasons.)
    skillRoot = skillLow.split(" ") // assumes concise skill format with '(noun) verb-ing' for all skills
    if (skillRoot.length >= 2) { // if it's two or more words, it's a noun skill
      skillVerb = skillRoot[1] // grab both the verb...
      skillNoun = skillRoot[0] // ...and the noun
    } else { // if it's only one word...
      skillVerb = skillLow // ...assume it's a verb-only skill
      if (typeof(skillNoun) !== 'undefined') { // sanity
        delete skillNoun // sanity
      }
    }
    
    skillVerb = skillVerb.split("ing")[0] // strip off 'ing' to get verb root
    
    skillMod = state.skills[skill] // get skill modifier from menu
    
    if (typeof(skillNoun) !== 'undefined') { // if there's a skillNoun, this is a noun+verb skill, so...
      skillBoosts[skillNoun] = skillMod // ...add the noun to the boosts, with the appropriate bonus
      if (skillMod >= 10) { // if skill is 10 or higher...
        loweredSkillMod = skillMod - 9 // ...make lower bonus...
        skillBoosts[skillVerb] = loweredSkillMod // ...and add the verb to the boosts as well
      }
    } else { // if there's no noun...
      skillBoosts[skillVerb] = skillMod // ...simply add the verb to boosts, with the appropriate bonus
    }
  }
  console.log(skillBoosts)
  
  // set up situational skill bonus:
  for (boost in skillBoosts) { // go through all boosts
    if (lowered.includes(boost)) { // check if input has skill word
      console.log("caught " + boost + " skill, adding boost")
      if (!state.chkSitBonus) { // make state.var to grab in contextMod
        state.chkSitBonus = 0
      }
      if (skillBoosts[boost] > state.chkSitBonus) { // if higher boost...
        state.chkSitBonus = skillBoosts[boost] // ...use it
      }
    }
  }
  
  if (!stopInput) { // if the AI gets used
    state.inputBot = 'InputDCattributeBot' // let InputDCattributeBot do her job
  }
  // END RPG mechanics
   
  return { text: modifiedText, stop:stopInput }
}

// Don't modify this part
modifier(text)
