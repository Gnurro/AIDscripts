
// Checkout the repo examples to get an idea of other ways you can use scripting 
// https://github.com/AIDungeon/Scripting/blob/master/examples

const modifier = (text) => {
  let modifiedText = text
  const lowered = text.toLowerCase()
    
  // The text passed in is either the user's input or players output to modify.
  // if(lowered.includes('/givesyl')) {    
    
    // state.message = toString(vowels.length)
    //state.message = makeWord(3)
    // modifiedText = text + '\nYou are now the king!'
  //}
  
  
  
  modifiedText = text
  // You must return an object with the text property defined.
  return { text: modifiedText }
}

// Don't modify this part
modifier(text)
