// Form shift and maintenance
// Adds [You are in your FORM form.] two lines back in context.
// Keeps up info message if toggled.
// Shows a hint at the beginning of an advanture to remind the player to take on a form. (Until ten actions have passed.)

const modifier = (text) => {
    const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ''
    const context = info.memoryLength ? text.slice(info.memoryLength) : text
    const lines = context.split("\n")
    
    if (state.form) {
      delete state.message
      const forminfo = "You are in your " + state.form + " form."
      lines.splice(-2, 0, `[${forminfo}]`)
      if (state.trackForm == true) {
        state.message = "You maintain your " + state.form + " form."
      }
    } else if (history.length <= 10) {
      state.message = "You have no specific form right now. Change into one!"
    }

    // Make sure the new context isn't too long, or it will get truncated by the server.
    const combinedLines = lines.join("\n").slice(-(info.maxChars - info.memoryLength))
    const finalText = [contextMemory, combinedLines].join("")
    return { text: finalText }
}
// Don't modify this part
modifier(text)
