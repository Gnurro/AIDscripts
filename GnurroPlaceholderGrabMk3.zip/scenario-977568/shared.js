// START of placeholder grab thing
const bracketed = /\[(.*?)\]/g // bracket definition; replace [ ] with symbol of choice - must match smybol used to encapsulate the placeholders in intro prompt!

// grab all bracketed things, put them into array in state
function grabAllBrackets() {
  for (entry of text.match(bracketed)) { // regExing return array, go through each entry in it
    entry = entry.replace(/\[|\]/g, '') // and remove the brackets
    if (!state.placeholders) { // if there isn't an array for this yet
      state.placeholders = new Array() // make it
    }
    state.placeholders.push(entry) // put the entries into array in state
  }
  console.log(state.placeholders) // to check
}

//grab only one specific bracketed thing, by count; use above function for longterm storage
function grabBracket(index) {
  return (text.match(bracketed)[index].replace(/\[|\]/g, ''))
}
// END of placeholder grab thing